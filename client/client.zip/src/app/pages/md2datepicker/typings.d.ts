// declare const module: {id: string};
