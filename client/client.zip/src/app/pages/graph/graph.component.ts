import { Component, OnInit } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { environment } from '../../config/config';
import { Router, ActivatedRoute } from '@angular/router';
import { ModalService } from '../../@theme/services/index';
import { StateService } from '../../@core/data/state.service';
import { EchartsBarComponent } from './echart/echarts-bar.component';
import { LocalDataSource } from 'ng2-smart-table';

@Component({
  selector: 'app-graph',
  templateUrl: './graph.component.html',
  styleUrls: ['./graph.component.scss']
})
export class GraphComponent implements OnInit {

  detail: any;
  current_type = "month";

  source: LocalDataSource = new LocalDataSource();
  adminUserInfo: any;

  table_settings = {
    actions: false,
    columns: {
      id: {
        title: 'ID',
        type: 'number',
      },
      user_name: {
        title: 'Customer Name',
        type: 'string',
      },
      phone_number: {
        title: 'PHONE NUMBER',
        type: 'string',
      },
      pass_type: {
        title: 'PASS TYPE',
        type: 'string',
      },
      timestamp: {
        title: 'Check in time',
        type: 'string',
      },
      duration: {
        title: 'Duration',
        type: 'string',
      }
    }
  };

  constructor(protected stateService: StateService, private http: Http, private router: Router, private modalService: ModalService) 
  {
  
  }

  ngOnInit() {
    this.adminUserInfo = JSON.parse(localStorage.getItem('admin_user'));
    if(this.adminUserInfo == null || this.adminUserInfo.user_token == undefined)
    {
      this.stateService.setlogout_show(true);
    }
    else
      this.stateService.setlogout_show(false);
    this.stateService.setselcted_setting(1);
    this.http.post(environment.api_url + 'getPendingRental', {})
      .subscribe(
        res => {
          let response = res.json();
          switch(response.result)
          {
            case -1:
              break;
            case 0:
              break;
            case 1:
              this.stateService.setpurchased_customercount(response.info.length);
              break;
          }
        },
        err => {
          console.log("Error occured");
        }
      );
    this.http.post(environment.api_url + 'getStatistics2', {})
    .subscribe(
      res => {
        let response = res.json();
        switch(response.result)
        {
          case -1:
            break;
          case 0:
            break;
          case 1:
            this.detail = response.detail;
            console.log("source", this.detail[1].detail);
            this.source.load(this.detail[1].detail);
            break;
        }
      },
      err => {
        console.log("Error occured");
      }
    );
  }

  selectType(type) {
    for(var i = 0; i < this.detail.length; i++)
    {
      if(this.detail[i].type == type)
      {
        this.source.load(this.detail[i].detail);
        break;
      }
    }
  }

}
