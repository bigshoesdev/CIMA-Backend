import {Component, OnInit, AfterViewChecked, ElementRef} from '@angular/core';

import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { environment } from '../../config/config';
import { Router, ActivatedRoute } from '@angular/router';
import { elementAt } from 'rxjs/operators/elementAt';
import { StateService } from '../../@core/data/state.service';
import $ from 'jquery'; 

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss']
})
export class SearchComponent implements AfterViewChecked {

  adminUserInfo: any;
  customerList = [];
  display_customerList = [];
  search_keyword = "";
  select_customer = {
    avatar_url: "",
    detail: [
    ],
    nric: "",
    user_name: ""
  };
  customerInfo_hide =  true;

  customerInfo_first = [];
  customerInfo_last = [];

  customerInfo_element_show = true;

  constructor(protected stateService: StateService, private http: Http, private router: Router,) {

  }

  public ngAfterViewChecked(): void {
    $('.user_avatar img').height($('.user_avatar img').width());
    $('.user_avatar1 img').height($('.user_avatar1 img').width());
  }     

  ngOnInit() {
    this.adminUserInfo = JSON.parse(localStorage.getItem('admin_user'));
    if(this.adminUserInfo == null || this.adminUserInfo.user_token == undefined)
    {
      this.stateService.setlogout_show(true);
    }
    else
      this.stateService.setlogout_show(false);

    this.stateService.setselcted_setting(2);
    this.http.post(environment.api_url + 'getPendingRental', {})
      .subscribe(
        res => {
          let response = res.json();
          switch(response.result)
          {
            case -1:
              break;
            case 0:
              break;
            case 1:
              this.stateService.setpurchased_customercount(response.info.length);
              break;
          }
        },
        err => {
          console.log("Error occured");
        }
      );
    this.http.post(environment.api_url + 'admin_home_getuser', {})
      .subscribe(
        res => {
          let response = res.json();
          switch(response.result)
          {
            case -1:
              this.router.navigate(['auth/login']);
              break;
            case 0:
              break;
            case 1:
              this.customerList = response.customers;
              this.display_customerList = response.customers;
              this.customerInfo_hide = false;
              this.select_customer = this.display_customerList[0];
              
              console.log("customerList", this.customerList);
              break;
          }
        },
        err => {
          console.log("Error occured");
        }
      );
  }

  search_by_customer_name() {
    this.display_customerList= [];
    console.log("keyword:", this.search_keyword);
    console.log("customer", this.customerList);
    for(var i = 0;  i < this.customerList.length; i++)
    {
      if(this.customerList[i].user_name.toUpperCase().indexOf(this.search_keyword.toUpperCase()) >= 0 || this.customerList[i].user_name.toLowerCase().indexOf(this.search_keyword.toLowerCase()) >= 0)
      {
        this.display_customerList.push(this.customerList[i]);
      }
    }

    console.log("display_customerList", this.display_customerList);
    if(this.display_customerList.length > 0)
    {
      this.customerInfo_hide = false;
      this.select_customer = this.display_customerList[0];
      console.log("nric", this.select_customer.nric);
    }
    else
      this.customerInfo_hide = true;
  }

  select_pass(index) {
    console.log("index", index);
    this.select_customer = this.display_customerList[index];

    this.customerInfo_first = [];
    for(var i = 0; i < 3; i++ )
    {
      this.customerInfo_first.push(this.select_customer.detail[i]);
    }
    this.customerInfo_last = [];
    for(var i = 3; i < 6; i++ )
    {
      this.customerInfo_last.push(this.select_customer.detail[i]);
    }

  }

  go_detail(phone_number) {
    this.router.navigate(['pages/customerInfo',phone_number]);
  }

}
