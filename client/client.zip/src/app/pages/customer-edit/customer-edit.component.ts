import {Component, OnInit, AfterViewChecked, ElementRef} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { LocalDataSource } from 'ng2-smart-table';
import { environment } from '../../config/config';
import { ModalService } from '../../@theme/services/index';
import { StateService } from '../../@core/data/state.service';
import $ from 'jquery'; 

@Component({
  selector: 'app-customer-edit',
  templateUrl: './customer-edit.component.html',
  styleUrls: ['./customer-edit.component.scss']
})

export class CustomerEditComponent implements AfterViewChecked {

  phone_number = "";
  adminUserInfo: any;
  personal = [{type: "NAME", value: ""}];
  emergency: any;
  qualification = [
    {type: "", message: "", checked: false},
    {type: "", message: "", checked: false},
    {type: "", message: "", checked: false},
    {type: "", message: "", checked: false},
    {type: "", message: "", checked: false},
    {type: "", message: "", checked: false},
    {type: "", message: "", checked: false},
  ];
  relationship = [
    "Parent", "Sibling", "Partner", "Friend"
  ]

  gender = [
    "Female", "Male"
  ]

  available_pass = [];
  special_note = "";
  customer_id = "";
  pass_buttons = [
    {
      type: "promo",
      available: false,
      title: "PROMO"
    },
    {
      type: "season",
      available: false,
      title: "SEASON"
    },
    {
      type: "multi",
      available: false,
      title: "MULTI"
    },
    {
      type: "day",
      available: false,
      title: "COMPLIMENTARY"
    },
  ];

  checkout_pass_buttons = [
    {
      type: "promo",
      available: false,
      title: "PROMO"
    },
    {
      type: "season",
      available: false,
      title: "SEASON"
    },
    {
      type: "multi",
      available: false,
      title: "MULTI"
    },
    {
      type: "day",
      available: false,
      title: "COMPLIMENTARY"
    },
  ];

  avatar_url: string;
  last_visit = "";
  visit_month = "";

  flag_check_btn = false;
  customerInfo: any;

  checkin_status = "";

  checkin_passtype = ""

  source: LocalDataSource = new LocalDataSource();

  pass_type = "";

  transaction_history = [];

  table_settings = {
    actions: false,
    columns: {
      id: {
        title: 'Transaction ID',
        type: 'number',
      },
      type: {
        title: 'Transaction Type',
        type: 'string',
      },
      date_time: {
        title: 'Date/Time',
        type: 'string',
      },
      action: {
        title: 'Action By',
        type: 'string',
      },
      notes: {
        title: 'Notes',
        type: 'string',
      }
    }
  };

  
  constructor(protected stateService: StateService, private http: Http, private router: Router, private route: ActivatedRoute, private modalService: ModalService) { }

  public ngAfterViewChecked(): void {
    $('.avatar img').height($('.avatar img').width());
    $('.modal-main-avatar img').height($('.modal-main-avatar img').width());
  }     

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      this.phone_number = params.get('phone_number');
    });
    this.adminUserInfo = JSON.parse(localStorage.getItem('admin_user'));
    if(this.adminUserInfo == null || this.adminUserInfo.user_token == undefined)
    {
      this.stateService.setlogout_show(true);
      this.router.navigate(['auth/login']);
    }
    else
      this.stateService.setlogout_show(false);

    this.http.post(environment.api_url + 'getPendingRental', {})
      .subscribe(
        res => {
          let response = res.json();
          switch(response.result)
          {
            case -1:
              break;
            case 0:
              break;
            case 1:
              this.stateService.setpurchased_customercount(response.info.length);
              break;
          }
        },
        err => {
          console.log("Error occured");
        }
      );

    // this.customerInfo = JSON.parse(localStorage.getItem('customerInfo'));
    // console.log("customerInfo", this.customerInfo);
    // this.personal = this.customerInfo.personal;
    // this.emergency = this.customerInfo.emergency;
    // this.qualification = this.customerInfo.qualification;
    // this.available_pass = this.customerInfo.available_pass;
    // this.special_note = this.customerInfo.special_note;
    // this.customer_id = this.customerInfo.customer_id;

    // for(var i = 0;  i < this.pass_buttons.length; i++)
    // {
    //   for(var j = 0; j < this.available_pass.length; j++)
    //   {
    //     if(this.pass_buttons[i].type == this.available_pass[j].type)
    //     {
    //       this.pass_buttons[i].available = true;
    //       this.pass_buttons[i].title = this.available_pass[j].message;
    //     }
    //   }
    // }

    // console.log("pass", this.available_pass);
    // this.avatar_url = this.customerInfo.avatar_url;
    // this.transaction_history = this.customerInfo.transaction_history;
    // this.source.load(this.transaction_history);
    // this.last_visit = this.customerInfo.last_visit;
    // this.visit_month = this.customerInfo.visit_month;
    // this.checkin_status = this.customerInfo.checkin_status;
    // if(this.customerInfo.available_pass.length > 0)
    //   this.pass_type = this.customerInfo.available_pass[0].type;
    // console.log("pass type", this.pass_type);
    // this.checkin_passtype = this.customerInfo.checkin_passtype;

    // for(var i = 0; i < this.checkout_pass_buttons.length; i++)
    // {
    //   if(this.checkout_pass_buttons[i].type == this.checkin_passtype)
    //     this.checkout_pass_buttons[i].available = true;
    // }

    let send_data = {
      customer_phone_number : this.phone_number
    }

    console.log("send Data", send_data);
  
    this.http.post(environment.api_url + 'admin_getCustomerInfo', send_data)
      .subscribe(
        res => {
          let response = res.json();
          switch(response.result)
          {
            case -1:
              this.router.navigate(['auth/login']);
              break;
            case 0:
              break;
            case 1:
              console.log("response", response);
              this.personal = response.personal;
              this.emergency = response.emergency;
              this.qualification = response.qualification;
              console.log("qualification", this.qualification);
              this.available_pass = response.available_pass;
              this.special_note = response.special_note;
              this.customer_id = response.customer_id;
            
              for(var i = 0;  i < this.pass_buttons.length; i++)
              {
                for(var j = 0; j < this.available_pass.length; j++)
                {
                  if(this.pass_buttons[i].type == this.available_pass[j].type)
                  {
                    this.pass_buttons[i].available = true;
                    this.pass_buttons[i].title = ((this.available_pass[j].type == 'promo') ? "complementary" : this.available_pass[j].type).toUpperCase();
                  }
                }
              }
              console.log("pass", this.available_pass);
              this.avatar_url = response.avatar_url;
              this.transaction_history = response.history.transaction_history;
              console.log("Transaction history", this.transaction_history);
              this.source.load(this.transaction_history);
              this.last_visit = response.history.last_visit;
              this.visit_month = response.history.visit_month;
              this.checkin_status = response.status;
              if(response.available_pass.length > 0)
                this.pass_type = response.available_pass[0].type;
              console.log("pass type", this.pass_type);
              this.checkin_passtype = response.checkin_passtype;

              for(var i = 0; i < this.checkout_pass_buttons.length; i++)
              {
                if(this.checkout_pass_buttons[i].type == this.checkin_passtype)
                  this.checkout_pass_buttons[i].available = true;
              }

              console.log("buttons", this.checkout_pass_buttons);
              break;
          }
        },
        err => {
          console.log("Error occured");
        }
      );
  }

  onDeleteConfirm(event): void {
    if (window.confirm('Are you sure you want to delete?')) {
      event.confirm.resolve();
    } else {
      event.confirm.reject();
    }
  }

  beforLeave()
  {
    var temp = {
      personal: this.personal,
      emergency: this.emergency,
      qualification: this.qualification,
      available_pass: this.available_pass,
      special_note: this.special_note,
      avatar_url: this.avatar_url,
      transaction_history: this.transaction_history,
      last_visit: this.last_visit,
      visit_month: this.visit_month,
      checkin_status: this.checkin_status,
      checkin_passtype: this.checkin_passtype,
      customer_id: this.customer_id
    }
    localStorage.setItem('customerInfo', JSON.stringify(temp));
  }
  go_save() {
    this.beforLeave();
    if(this.personal[0].value.indexOf(" ") <= 0)
    {
      alert("Plese input name correctly. first name and last name is not splited.");
      return;
    }
    var temp = JSON.parse(localStorage.getItem('customerInfo'));
    console.log("temp", temp);

    if(this.adminUserInfo == null || this.adminUserInfo.user_token == undefined)
    {
      this.router.navigate(['auth/login']);
      return;
    }
      

    let send_data = {
      user_token: this.adminUserInfo.user_token,
      customerInfo: temp
    }

    console.log("send Data*******", send_data);
  
    this.http.post(environment.api_url + 'admin_customer_update', send_data)
      .subscribe(
        res => {
          let response = res.json();
          switch(response.result)
          {
            case -1:
              this.router.navigate(['auth/login']);
              break;
            case 0:
              break;
            case 1:
              this.router.navigate(['pages/customerInfo/' +  this.phone_number]);
              console.log("OKKKKOKKOKI");
              break;
          }
        },
        err => {
          console.log("Error occured");
        }
      );
    // this.router.navigate(['pages/addPass']);
  }

  go_edit(pass_type)
  {
    if(pass_type != "season" && pass_type != "promo")
    {
      this.router.navigate(['/pages/editotherpass/' + pass_type + '/' + this.phone_number]);
    }
    else if(pass_type == "season")
      this.router.navigate(['/pages/editseasonpass/' + pass_type + '/' + this.phone_number]);
  }
}
