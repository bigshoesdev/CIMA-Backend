import { Component } from '@angular/core';

@Component({
  selector: 'app-equipment',
  template: `<router-outlet></router-outlet>`,
})
export class EquipmentComponent{

}
