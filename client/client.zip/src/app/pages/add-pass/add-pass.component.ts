import { Component, OnInit } from '@angular/core';
import {Location} from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { environment } from '../../config/config';
import { ModalService } from '../../@theme/services/index';
import { concat } from 'rxjs/operator/concat';
import { StateService } from '../../@core/data/state.service';
import { NumberPickerComponent } from '../numberpicker/number-picker.component';
import { MonthpickerComponent } from '../monthpicker/monthpicker.component';

@Component({
  selector: 'app-add-pass',
  templateUrl: './add-pass.component.html',
  styleUrls: ['./add-pass.component.scss']
})
export class AddPassComponent implements OnInit {

  adminUserInfo: any;
  available_pass = [];
  start_date = new Date().toDateString();
  selected_pass_type = "";
  datePickerConfig = {
    format: "YYYY/MM"
  }
  customer_id = "";
  

  sidebars = [];

  quantity = 1;

  note = "";

  pass_type = [
    {
      type: "promo",
      title: "COMPLIMENTARY"
    },
    {
      type: "multi_5",
      title: "MULTI_FIVE"
    },
    {
      type: "multi_10",
      title: "MULTI_TEN"
    },
    {
      type: "day",
      title: "DAY"
    },
  ];

  phone_number = "";

  constructor(protected stateService: StateService, private http: Http, private _location: Location, private router: Router, private modalService: ModalService, private route: ActivatedRoute,) 
  {
  }
  ngOnInit() {

    this.route.paramMap.subscribe(params => {
      this.phone_number = params.get('phone_number');
    });
    this.adminUserInfo = JSON.parse(localStorage.getItem('admin_user'));
    if(this.adminUserInfo == null || this.adminUserInfo.user_token == undefined)
    {
      this.stateService.setlogout_show(true);
      this.router.navigate(['auth/login']);
    }
    else
      this.stateService.setlogout_show(false);

    this.http.post(environment.api_url + 'getPendingRental', {})
      .subscribe(
        res => {
          let response = res.json();
          switch(response.result)
          {
            case -1:
              break;
            case 0:
              break;
            case 1:
              this.stateService.setpurchased_customercount(response.info.length);
              break;
          }
        },
        err => {
          console.log("Error occured");
        }
      );

    let send_data = {
      customer_phone_number : this.phone_number
    }

    console.log("send Data", send_data);
  
    this.http.post(environment.api_url + 'admin_getCustomerInfo', send_data)
      .subscribe(
        res => {
          let response = res.json();
          switch(response.result)
          {
            case -1:
              // this.router.navigate(['auth/login']);
              break;
            case 0:
              break;
            case 1:
              console.log("response", response);
              this.available_pass = response.available_pass;
              this.customer_id = response.customer_id;
              // this.start_date = new Date();

              for(var i = 0;  i < this.pass_type.length; i++)
              {
                if(this.pass_type[i].type == "promo" )
                {
                  if(response.used_promo == true)
                  {
                    this.pass_type.splice(i, 1);
                  }
                }
              }
              this.selected_pass_type = this.pass_type[0].type;
              this.quantity = 1;
              break;
          }
        },
        err => {
          console.log("Error occured");
        }
      );

    
  }

  selectPass(pass_type) {
    this.selected_pass_type = pass_type;
  }

  add_pass()
  {
    let from = new Date(this.start_date).getTime();
    let temp_from = new Date(this.start_date);

    let to, message;
    switch(this.selected_pass_type)
    {
      case "promo":
        to = "";
        message = "COMPLEMENTARY PASS";
        let temp = {
          type: this.selected_pass_type,
          from: from,
          to: to,
          quantity: (this.selected_pass_type == "promo") ? 1 : this.quantity,
          used: false,
          message: message,
          status: "add",
          expire: "",
          changing: "COMPLEMENTARY PASS ADDED"
        }
        this.available_pass.push(temp);
        break;
      case "multi_5":
        console.log("from: 1", from);
        temp_from.setMonth(temp_from.getMonth() + 6 );
        to = temp_from.getTime();
        console.log("to: 1", to);
        message = "MULTI PASS";
        var flag = false;
        for(var i =0; i < this.available_pass.length; i++)
        {
          if(this.available_pass[i].type == "multi")
          {
            this.available_pass[i].from = (this.available_pass[i].from <= from) ? this.available_pass[i].from : from;
            this.available_pass[i].to = (this.available_pass[i].to >= to) ? this.available_pass[i].to : to;
            this.available_pass[i].quantity += this.quantity * 5;
            this.available_pass[i].status  += "edit";
            this.available_pass[i].expire = new Date(this.available_pass[i].to).toDateString();
            this.available_pass[i].changing = "CHANGED " + message + " INTO " + this.available_pass[i].quantity;
            flag = true;
            break;
          }
        }
        if(flag == false)
        {
          console.log("from: 2", from);
          console.log("to: 2", to);
          let temp = {
            type: "multi",
            from: from,
            to: to,
            quantity: this.quantity * 5,
            used: false,
            message: message,
            status: "add",
            first_add: this.quantity,
            expire: new Date(to).toDateString(),
            changing: "CHANGED " + message + " INTO " + this.quantity * 5
          }
          this.available_pass.push(temp);
        }
        break;

      case "multi_10":
        temp_from.setMonth(temp_from.getMonth() + 6 );
        to = temp_from.getTime();
        message = "MULTI PASS";
        var flag = false;
        for(var i =0; i < this.available_pass.length; i++)
        {
          if(this.available_pass[i].type == "multi")
          {
            this.available_pass[i].from = (this.available_pass[i].from <= from) ? this.available_pass[i].from : from;
            this.available_pass[i].to = (this.available_pass[i].to >= to) ? this.available_pass[i].to : to;
            this.available_pass[i].quantity += this.quantity * 10;
            this.available_pass[i].status  += "edit";
            this.available_pass[i].expire = new Date(this.available_pass[i].to).toDateString();
            this.available_pass[i].changing = "CHANGED " + message + " INTO " + this.available_pass[i].quantity;
            flag = true;
            break;
          }
        }
        if(flag == false)
        {
          let temp = {
            type: "multi",
            from: from,
            to: to,
            quantity: this.quantity * 10,
            used: false,
            message: message,
            status: "add",
            first_add: this.quantity,
            expire: new Date(to).toDateString(),
            changing: "CHANGED " + message + " INTO " + this.quantity * 10
          }
          this.available_pass.push(temp);
        }
        break;
        
      case "day":
        temp_from.setDate(temp_from.getDate() + 7);
        to = temp_from.getTime();
        message = "DAY PASS";
        var flag = false;
        for(var i =0; i < this.available_pass.length; i++)
        {
          if(this.available_pass[i].type == "day")
          {
            this.available_pass[i].from = (this.available_pass[i].from <= from) ? this.available_pass[i].from : from;
            this.available_pass[i].to = (this.available_pass[i].to >= to) ? this.available_pass[i].to : to;
            this.available_pass[i].quantity += this.quantity;
            this.available_pass[i].status  += "edit";
            this.available_pass[i].expire = new Date(this.available_pass[i].to).toDateString();
            this.available_pass[i].changing = "CHANGED " + message + " INTO " + this.available_pass[i].quantity;
            flag = true;
            break;
          }
        }
        if(flag == false)
        {
          let temp = {
            type: this.selected_pass_type,
            from: from,
            to: to,
            quantity: this.quantity,
            used: false,
            message: message,
            status: "add",
            first_add: this.quantity, 
            expire: new Date(to).toDateString(),
            changing: "CHANGED " + message + " INTO " + this.quantity
          }
          this.available_pass.push(temp);
        }
        break;
    }

   
    // console.log("customerInfo", this.customerInfo);
    // this.available_pass = this.customerInfo.available_pass;
   
    // localStorage.setItem('customerInfo', JSON.stringify(this.customerInfo));
    let send_data = {
      user_token: this.adminUserInfo.user_token,
      pass: this.available_pass,
      customer_id: this.customer_id
    }
    this.http.post(environment.api_url + 'admin_pass_update', send_data)
      .subscribe(
        res => {
          let response = res.json();
          switch(response.result)
          {
            case -1:
              this.router.navigate(['auth/login']);
              break;
            case 0:
              break;
            case 1:
              this._location.back();
              break;
          }
        },
        err => {
          console.log("Error occured");
        }
      );
    // admin_pass_update
  }

  onNumberChanged($event) {
    this.quantity = $event;
  }
}
