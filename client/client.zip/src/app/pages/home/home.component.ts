import {Component, OnInit, AfterViewChecked, ElementRef} from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { environment } from '../../config/config';
import { Router, ActivatedRoute } from '@angular/router';
import { elementAt } from 'rxjs/operators/elementAt';
import { ModalService } from '../../@theme/services/index';
import { StateService } from '../../@core/data/state.service';
import $ from 'jquery';

import * as io from 'socket.io-client';

@Component({
  moduleId: module.id.toString(),
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})

export class HomeComponent implements AfterViewChecked {
  phone_number = "";
  user_name = "";
  live_count: Number;
  adminUserInfo: any;
  customerList = [];
  user_avatar = "";
  visit_to_date: Number;
  socket = null;

  constructor(protected stateService: StateService, private http: Http, private router: Router, private modalService: ModalService) 
  {
  }

  ngOnInit() {
    // localStorage.setItem('admin_user', JSON.stringify({}));
    
    this.stateService.deselectall();
    this.adminUserInfo = JSON.parse(localStorage.getItem('admin_user'));
    console.log("admin_userInfo", this.adminUserInfo);
    if(this.adminUserInfo == null || this.adminUserInfo.user_token == undefined)
    {
      this.stateService.setlogout_show(true);
    }
    else
      this.stateService.setlogout_show(false);

    this.http.post(environment.api_url + 'getPendingRental', {})
    .subscribe(
      res => {
        let response = res.json();
        switch(response.result)
        {
          case -1:
            break;
          case 0:
            break;
          case 1:
            this.stateService.setpurchased_customercount(response.info.length);
            break;
        }
      },
      err => {
        console.log("Error occured");
      }
    );
    
    this.http.post(environment.api_url + 'admin_home_getuser', {})
      .subscribe(
        res => {
          let response = res.json();
          switch(response.result)
          {
            case -1:
              this.router.navigate(['auth/login']);
              break;
            case 0:
              break;
            case 1:
              this.live_count = response.live_count;
              this.visit_to_date = response.visit_to_date;
              console.log("live_count", this.live_count);
              this.customerList = response.customers;
              console.log("customerList", this.customerList);
             
              break;
          }
        },
        err => {
          console.log("Error occured");
        }
      );
  }

  public ngAfterViewChecked(): void {
    $('.user_avatar img').height($('.user_avatar img').width());
    $('.modal-main-avatar img').height($('.modal-main-avatar img').width());
  }       


  go_checkin(phone_number, mode) {
    if(mode == "image")
    {
      console.log("PHONE NUMBER:", phone_number);
      let userInfo = JSON.parse(localStorage.getItem('admin_user'));

      this.adminUserInfo = JSON.parse(localStorage.getItem('admin_user'));

      if(userInfo == null || userInfo.user_token == undefined)
      {
        return;
      }

      let send_data = {
        customer_phone_number: phone_number
      }
  
      console.log("send Data", send_data);
    
      this.http.post(environment.api_url + 'admin_validate_phone_number', send_data)
        .subscribe(
          res => {
            let response = res.json();
            switch(response.result)
            {
              case -1:
                this.router.navigate(['auth/login']);
                break;
              case 0:
                // this.openModal('error_modal');
                break;
              case 1:
                this.user_avatar = response.user_avatar;
                this.user_name = response.name;
                console.log("phone_number", response.phone_number);
                this.phone_number = response.phone_number;
                this.openModal('phone_number_modal')
                break;
            }
          },
          err => {
            console.log("Error occured");
          }
        );
    }
    else
    {
      let send_data = {
        customer_phone_number: phone_number
      }
  
      console.log("send Data", send_data);
    
      this.http.post(environment.api_url + 'admin_validate_phone_number', send_data)
        .subscribe(
          res => {
            let response = res.json();
            switch(response.result)
            {
              case -1:
                this.router.navigate(['auth/login']);
                break;
              case 0:
                this.openModal('error_modal');
                break;
              case 1:
                this.user_avatar = response.user_avatar;
                this.user_name = response.name;
                console.log("phone_number", response.phone_number);
                this.phone_number = response.phone_number;
                this.openModal('phone_number_modal')
                break;
            }
          },
          err => {
            console.log("Error occured");
          }
        );
    }
   
  }

  openModal(id: string){
    this.modalService.open(id);
  }

  closeModal(id: string){
    this.modalService.close(id);
  }

  validate_phone_number(id: string) {
    this.modalService.close(id);
    console.log(this.phone_number);

    this.router.navigate(['pages/customerInfo',this.phone_number]);
  }

}
