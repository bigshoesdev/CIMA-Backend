export const environment = {
    'api_url': 'http://192.168.12.226:3000/api/',
    'websocket_url': 'http://192.168.12.226:3500',
};